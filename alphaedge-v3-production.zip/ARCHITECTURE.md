# AlphaEdge v3 — Architecture

## Stack
| Layer | Technology | Status |
|-------|-----------|--------|
| Backend | FastAPI (Python 3.11+) | ✅ Implemented |
| Database | Postgres 16 + pgvector | ✅ Implemented |
| Embeddings | OpenAI text-embedding-3-small | ✅ Implemented |
| LLM | Claude Sonnet 4 (Anthropic) | ✅ Implemented |
| Market Data | yfinance (free, no key) | ✅ Implemented |
| Async Queue | ARQ + Redis (optional, sync fallback) | ✅ Implemented |
| Frontend | React bundle (v1, needs v3 update) | ⚠️ Partial |
| Notion | Not implemented in v3 | ❌ Removed |
| FRED | Not implemented (macro via RAG docs) | ❌ Not present |

## Data Flow
```
[PDF Upload / .md files]
       │
       ▼
[Chunk + Embed (OpenAI)] → [Postgres/pgvector: document_chunks]
                                    │
[User: "Analyze NVDA, PLTR"]       │
       │                           │
       ▼                           ▼
[PAM Engine (deterministic)]   [RAG Retrieval (cosine search)]
  - yfinance OHLCV                  │
  - Flow: HH/HL vs LH/LL          │
  - Momentum: wave vs flush        │
  - Pattern: UC1/UR2/DR2/DC1       │
  - Rotation: A/B/C/D              │
  - Micro score                    │
       │                           │
       ▼                           ▼
[Chain Prompting: 4 LLM calls]
  A. Context Builder → assembles brief
  B. Analyst → macro/theme scores + thesis
  C. Critic → validates, caps inflation
  D. Formatter → strict JSON
       │
       ▼
[Logistic Scoring] → p = 100/(1+exp(-k*(raw-c)))
       │
       ▼
[Options Mapper] → Bang Van IV×Direction matrix
       │
       ▼
[Position Sizing] → min(Piranha 2% rule, quarter-Kelly)
       │
       ▼
[Postgres: trade_ideas + pam_signals]
```

## API Endpoints
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/analyze | Submit watchlist → returns job_id |
| GET | /api/jobs/{id} | Poll job results |
| GET | /api/pam/{ticker} | Direct PAM engine output |
| GET | /api/score/test | Test logistic scoring |
| POST | /api/upload/pdf | Upload PDF to knowledge base |
| GET | /api/collections | List pgvector collections |
| POST | /api/journal | Create trade journal entry |
| PUT | /api/journal/close | Close trade with P/L |
| GET | /api/journal | List journal entries |
| GET | /api/health | Health check |
| GET | /docs | Swagger UI |

## Knowledge Collections (pgvector)
| Collection | Content |
|---|---|
| macro_liquidity | Howell framework, GLI, Fed, DXY |
| trading_methods | Adam Khoo, Bang Van, options strategies |
| pam_structures | PAM setups, momentum, rotation model |
| tech_reports | AI/semis/hyperscaler reports |
| watchlist_setups | Specific ticker setups |
