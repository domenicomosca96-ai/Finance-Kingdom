# AlphaEdge v3 — Deploy Guide

## Prerequisites
- Python 3.11+
- Postgres 16 with pgvector extension
- Redis (optional — sync fallback works without it)
- API keys: Anthropic + OpenAI

## Option 1: Docker Compose (recommended)

```bash
cp .env.example .env
# Edit .env with your ANTHROPIC_API_KEY and OPENAI_API_KEY

docker-compose up -d
# Postgres + Redis start automatically
# App runs on http://localhost:8000

# Bootstrap knowledge base
docker-compose exec app python -m backend.bootstrap
```

## Option 2: Local

```bash
# 1. Start Postgres with pgvector
docker run -d --name alphaedge-db \
  -e POSTGRES_USER=alpha -e POSTGRES_PASSWORD=alpha -e POSTGRES_DB=alphaedge \
  -p 5432:5432 pgvector/pgvector:pg16

# 2. Setup app
bash setup.sh
# Or manually:
python3.11 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # edit with your keys
python -m backend.bootstrap
python -m backend.main
```

## Option 3: Railway / Render
1. Push to GitHub
2. Connect to Railway/Render
3. Add Postgres addon (both support pgvector)
4. Set environment variables from .env.example
5. Build: `pip install -r requirements.txt`
6. Start: `uvicorn backend.main:app --host 0.0.0.0 --port $PORT`
7. Run bootstrap: `python -m backend.bootstrap`

## Adding Knowledge
- Drop .md files in `data/knowledge/` → run `python -m backend.bootstrap`
- Drop .pdf files in `data/pdfs/` → run `python -m backend.bootstrap`
- Or upload PDFs via `POST /api/upload/pdf` (dashboard or curl)

## Costs
| Service | Cost |
|---------|------|
| Anthropic (Claude Sonnet) | ~$3/1M tokens |
| OpenAI (embeddings only) | ~$0.02/1M tokens |
| yfinance | Free, no key |
| Postgres | Free (Docker) or ~$5/mo (Railway) |
| **Total for ~50 analyses/day** | **~$10-15/month** |
