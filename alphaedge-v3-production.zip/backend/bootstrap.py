"""
Bootstrap — Load knowledge into Postgres/pgvector with deduplication.

Features:
  - Hash-based dedup: skips files already ingested (by content hash)
  - Upsert: replaces chunks if file content changed
  - Cleanup: can purge a source before re-ingesting
  - Tracks source + hash in metadata

Usage: python -m backend.bootstrap [--force]
"""

import sys
import hashlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy import text
from sqlalchemy.orm import Session
from langchain.text_splitter import RecursiveCharacterTextSplitter
from backend.config import settings
from backend.db.session import init_db_sync, sync_engine
from backend.db.models import DocumentChunk
from backend.ingestion.retrieval import embed_batch

KNOWLEDGE_DIR = Path(__file__).parent.parent / "data" / "knowledge"
PDF_DIR = Path(__file__).parent.parent / "data" / "pdfs"

COLLECTION_MAP = {
    "liquidity": "macro_liquidity", "macro": "macro_liquidity", "howell": "macro_liquidity",
    "fed": "macro_liquidity",
    "trading": "trading_methods", "khoo": "trading_methods", "bang": "trading_methods",
    "method": "trading_methods", "option": "trading_methods", "strategy": "trading_methods",
    "pam": "pam_structures", "manipulation": "pam_structures", "smc": "pam_structures",
    "accumulation": "pam_structures", "distribution": "pam_structures", "rotation": "pam_structures",
    "momentum": "pam_structures", "reversal": "pam_structures", "ur2": "pam_structures",
    "dr2": "pam_structures", "uc1": "pam_structures",
    "tech": "tech_reports", "semiconductor": "tech_reports", "nvidia": "tech_reports",
    "equity": "tech_reports", "playbook": "tech_reports",
}

splitter = RecursiveCharacterTextSplitter(chunk_size=1200, chunk_overlap=200)


def resolve_collection(filename: str) -> str:
    name_lower = filename.lower()
    for pattern, collection in COLLECTION_MAP.items():
        if pattern in name_lower:
            return collection
    return "tech_reports"


def content_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def is_already_ingested(db: Session, source: str, file_hash: str) -> bool:
    """Check if this exact file version is already in the DB."""
    result = db.execute(
        text("SELECT count(*) FROM document_chunks WHERE source = :s AND metadata->>'hash' = :h"),
        {"s": source, "h": file_hash},
    )
    return result.scalar() > 0


def delete_source(db: Session, source: str):
    """Remove all chunks for a source (before re-ingesting updated version)."""
    db.execute(text("DELETE FROM document_chunks WHERE source = :s"), {"s": source})
    db.commit()


def ingest_text(db: Session, text_content: str, source: str, collection: str, force: bool = False) -> int:
    """Chunk, embed, and insert with dedup."""
    file_hash = content_hash(text_content)

    if not force and is_already_ingested(db, source, file_hash):
        return -1  # already present, skip

    # Delete old version if exists (upsert behavior)
    delete_source(db, source)

    chunks = splitter.split_text(text_content)
    if not chunks:
        return 0

    embeddings = embed_batch(chunks)

    for i, (chunk, emb) in enumerate(zip(chunks, embeddings)):
        db.add(DocumentChunk(
            collection=collection,
            source=source,
            chunk_index=i,
            content=chunk,
            embedding=emb,
            metadata_={"hash": file_hash, "total_chunks": len(chunks)},
        ))
    db.commit()
    return len(chunks)


def run_bootstrap(force: bool = False):
    print("\n" + "=" * 60)
    print("  AlphaEdge — Knowledge Bootstrap (pgvector + dedup)")
    print("=" * 60 + "\n")

    init_db_sync()
    print("  ✓ Database ready\n")

    KNOWLEDGE_DIR.mkdir(parents=True, exist_ok=True)
    PDF_DIR.mkdir(parents=True, exist_ok=True)

    total_new = 0
    total_skipped = 0

    with Session(sync_engine) as db:
        # Markdown files
        md_files = sorted(KNOWLEDGE_DIR.glob("*.md"))
        if md_files:
            print(f"📚 Markdown files ({len(md_files)}):\n")
            for f in md_files:
                try:
                    text_content = f.read_text(encoding="utf-8")
                    collection = resolve_collection(f.name)
                    n = ingest_text(db, text_content, f.name, collection, force)
                    if n == -1:
                        print(f"  ⏭ {f.name} (unchanged, skipped)")
                        total_skipped += 1
                    else:
                        print(f"  ✓ {f.name} → {collection} ({n} chunks)")
                        total_new += n
                except Exception as e:
                    print(f"  ✗ {f.name}: {e}")

        # PDF files
        pdf_files = sorted(PDF_DIR.glob("*.pdf"))
        if pdf_files:
            print(f"\n📄 PDF files ({len(pdf_files)}):\n")
            try:
                import fitz
            except ImportError:
                print("  ⚠ PyMuPDF not installed, skipping PDFs")
                pdf_files = []

            for f in pdf_files:
                try:
                    doc = fitz.open(str(f))
                    text_content = "\n\n".join(p.get_text("text") for p in doc if p.get_text("text").strip())
                    doc.close()
                    if not text_content.strip():
                        print(f"  ⚠ {f.name}: no text")
                        continue
                    collection = resolve_collection(f.name)
                    n = ingest_text(db, text_content, f.name, collection, force)
                    if n == -1:
                        print(f"  ⏭ {f.name} (unchanged, skipped)")
                        total_skipped += 1
                    else:
                        print(f"  ✓ {f.name} → {collection} ({n} chunks)")
                        total_new += n
                except Exception as e:
                    print(f"  ✗ {f.name}: {e}")

        # Summary
        result = db.execute(text(
            "SELECT collection, count(*) FROM document_chunks GROUP BY collection ORDER BY collection"
        ))
        print(f"\n{'─' * 60}")
        print(f"  New: {total_new} chunks | Skipped: {total_skipped} files\n")
        print("  Collections:")
        for row in result:
            print(f"    {row[0]}: {row[1]} chunks")
        print(f"\n{'=' * 60}\n")


if __name__ == "__main__":
    force = "--force" in sys.argv
    run_bootstrap(force)
