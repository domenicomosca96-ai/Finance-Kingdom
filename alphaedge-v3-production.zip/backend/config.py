"""Centralized configuration — only variables actually used by the codebase."""

import os
from dotenv import load_dotenv

load_dotenv()


class Settings:
    # AI Keys (required)
    ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")

    # Postgres + pgvector (required)
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        "postgresql+asyncpg://alpha:alpha@localhost:5432/alphaedge",
    )
    DATABASE_URL_SYNC: str = os.getenv(
        "DATABASE_URL_SYNC",
        "postgresql://alpha:alpha@localhost:5432/alphaedge",
    )

    # Redis (optional — sync fallback if absent)
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379")

    # Scoring (logistic sigmoid)
    SCORE_THRESHOLD: float = float(os.getenv("SCORE_THRESHOLD", "65"))
    LOGISTIC_K: float = float(os.getenv("LOGISTIC_K", "0.08"))
    LOGISTIC_C: float = float(os.getenv("LOGISTIC_C", "55"))

    # Weights
    W_MACRO: float = float(os.getenv("W_MACRO", "0.30"))
    W_THEME: float = float(os.getenv("W_THEME", "0.25"))
    W_PAM: float = float(os.getenv("W_PAM", "0.45"))

    # Risk Management
    KELLY_FRACTION: float = float(os.getenv("KELLY_FRACTION", "0.25"))
    MAX_POSITION_PCT: float = float(os.getenv("MAX_POSITION_PCT", "5.0"))
    MAX_RISK_PER_TRADE_PCT: float = float(os.getenv("MAX_RISK_PER_TRADE_PCT", "2.0"))
    MAX_PORTFOLIO_HEAT_PCT: float = float(os.getenv("MAX_PORTFOLIO_HEAT_PCT", "6.0"))
    PORTFOLIO_SIZE: float = float(os.getenv("PORTFOLIO_SIZE", "100000"))

    # LLM
    MODEL: str = os.getenv("LLM_MODEL", "claude-sonnet-4-20250514")
    EMBEDDING_MODEL: str = "text-embedding-3-small"
    EMBEDDING_DIM: int = 1536


settings = Settings()
