"""
SQLAlchemy models — Postgres + pgvector.

Tables:
  document_chunks   — RAG vector store (replaces ChromaDB)
  daily_bars        — OHLCV market data cache
  pam_signals       — Deterministic PAM engine outputs
  trade_ideas       — AI-generated trade ideas with scores
  journal           — Trade journal for feedback loop
  analysis_jobs     — Async job tracking (ARQ)
"""

from datetime import datetime, date
from sqlalchemy import (
    Column, String, Float, Integer, Boolean, Text, Date, DateTime,
    JSON, ForeignKey, Index, UniqueConstraint, Enum as SAEnum,
)
from sqlalchemy.orm import declarative_base, relationship
from pgvector.sqlalchemy import Vector
from backend.config import settings
import enum

Base = declarative_base()


# ═══════════════════════════════════════════════════════════
#  ENUMS
# ═══════════════════════════════════════════════════════════

class CollectionType(str, enum.Enum):
    MACRO_LIQUIDITY = "macro_liquidity"
    TRADING_METHODS = "trading_methods"
    PAM_STRUCTURES = "pam_structures"
    TECH_REPORTS = "tech_reports"
    WATCHLIST_SETUPS = "watchlist_setups"


class Direction(str, enum.Enum):
    LONG = "long"
    SHORT = "short"
    NEUTRAL = "neutral"


class FlowState(str, enum.Enum):
    POSITIVE = "positive_flow"      # HH/HL above 50 SMA
    NEGATIVE = "negative_flow"      # LH/LL below 50 SMA
    TRANSITION_UP = "transition_up"
    TRANSITION_DOWN = "transition_down"
    RANGING = "ranging"


class PAMPattern(str, enum.Enum):
    UC1 = "UC1"    # Upside Continuation 1
    UC2 = "UC2"    # Upside Continuation 2
    UR1 = "UR1"    # Upside Reversal 1
    UR2 = "UR2"    # Upside Reversal 2
    DC1 = "DC1"    # Downside Continuation 1
    DC2 = "DC2"    # Downside Continuation 2
    DR1 = "DR1"    # Downside Reversal 1
    DR2 = "DR2"    # Downside Reversal 2
    NONE = "NONE"


class JobStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETE = "complete"
    FAILED = "failed"


# ═══════════════════════════════════════════════════════════
#  DOCUMENT CHUNKS (pgvector RAG store)
# ═══════════════════════════════════════════════════════════

class DocumentChunk(Base):
    __tablename__ = "document_chunks"

    id = Column(Integer, primary_key=True, autoincrement=True)
    collection = Column(String(50), nullable=False, index=True)
    source = Column(String(500), nullable=False)
    chunk_index = Column(Integer, nullable=False)
    content = Column(Text, nullable=False)
    embedding = Column(Vector(settings.EMBEDDING_DIM), nullable=False)
    metadata_ = Column("metadata", JSON, default={})
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_chunks_embedding", "embedding", postgresql_using="ivfflat",
              postgresql_with={"lists": 100},
              postgresql_ops={"embedding": "vector_cosine_ops"}),
    )


# ═══════════════════════════════════════════════════════════
#  DAILY BARS (OHLCV cache)
# ═══════════════════════════════════════════════════════════

class DailyBar(Base):
    __tablename__ = "daily_bars"

    id = Column(Integer, primary_key=True, autoincrement=True)
    ticker = Column(String(20), nullable=False, index=True)
    dt = Column(Date, nullable=False)
    open = Column(Float, nullable=False)
    high = Column(Float, nullable=False)
    low = Column(Float, nullable=False)
    close = Column(Float, nullable=False)
    volume = Column(Float, nullable=False)

    # Pre-computed indicators (filled by market_data.py)
    sma_20 = Column(Float)
    sma_50 = Column(Float)
    sma_150 = Column(Float)
    ema_20 = Column(Float)
    ema_50 = Column(Float)
    atr_14 = Column(Float)
    rsi_14 = Column(Float)

    __table_args__ = (
        UniqueConstraint("ticker", "dt", name="uq_ticker_date"),
    )


# ═══════════════════════════════════════════════════════════
#  PAM SIGNALS (deterministic engine output)
# ═══════════════════════════════════════════════════════════

class PAMSignal(Base):
    __tablename__ = "pam_signals"

    id = Column(Integer, primary_key=True, autoincrement=True)
    ticker = Column(String(20), nullable=False, index=True)
    dt = Column(Date, nullable=False)

    # Flow & trend
    flow_state = Column(String(30), nullable=False)
    above_sma50 = Column(Boolean, nullable=False)
    hh_hl_count = Column(Integer, default=0)    # consecutive HH/HL
    lh_ll_count = Column(Integer, default=0)    # consecutive LH/LL

    # Pattern detection
    pattern = Column(String(10), default="NONE")
    pattern_confidence = Column(Float, default=0.0)   # 0-100
    trigger_level = Column(Float)                      # price to confirm
    stop_level = Column(Float)
    target_level = Column(Float)

    # Momentum
    flush_detected = Column(Boolean, default=False)
    flush_direction = Column(String(10))               # "up" or "down"
    momentum_angle_deg = Column(Float)                 # approx degrees
    is_wave = Column(Boolean, default=False)           # ~45° movement
    is_flush = Column(Boolean, default=False)          # >70° movement

    # Accumulation/Distribution segment
    rotation_segment = Column(String(5))               # A, B, C, D

    # Raw micro score (0-100) from deterministic rules
    micro_score = Column(Float, default=50.0)

    metadata_ = Column("metadata", JSON, default={})
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("ticker", "dt", name="uq_pam_ticker_date"),
    )


# ═══════════════════════════════════════════════════════════
#  TRADE IDEAS (AI-generated)
# ═══════════════════════════════════════════════════════════

class TradeIdea(Base):
    __tablename__ = "trade_ideas"

    id = Column(Integer, primary_key=True, autoincrement=True)
    job_id = Column(String(50), ForeignKey("analysis_jobs.job_id"), index=True)
    ticker = Column(String(20), nullable=False, index=True)
    dt = Column(Date, nullable=False)

    # Scores
    raw_macro = Column(Float, default=50.0)
    raw_theme = Column(Float, default=50.0)
    raw_pam = Column(Float, default=50.0)       # from PAMSignal.micro_score
    raw_composite = Column(Float, default=50.0)
    probability_pct = Column(Float, default=50.0)  # logistic-transformed

    # Trade plan
    direction = Column(String(10), default="neutral")
    actionable = Column(Boolean, default=False)
    thesis = Column(Text)
    swing_plan = Column(Text)
    entry_price = Column(Float)
    stop_loss = Column(Float)
    target_price = Column(Float)

    # Options
    option_strategy = Column(String(50))
    option_legs = Column(JSON)
    option_rationale = Column(Text)
    payoff_matrix = Column(JSON)

    # Position sizing
    kelly_fraction = Column(Float)
    suggested_capital = Column(Float)
    suggested_contracts = Column(Integer)
    max_risk_dollars = Column(Float)

    # Meta
    invalidation = Column(Text)
    catalysts = Column(JSON, default=[])
    llm_raw_output = Column(Text)                  # full LLM response for audit
    created_at = Column(DateTime, default=datetime.utcnow)


# ═══════════════════════════════════════════════════════════
#  JOURNAL (Notion write-back + local record)
# ═══════════════════════════════════════════════════════════

class JournalEntry(Base):
    __tablename__ = "journal"

    id = Column(Integer, primary_key=True, autoincrement=True)
    trade_idea_id = Column(Integer, ForeignKey("trade_ideas.id"), nullable=True)
    notion_page_id = Column(String(100))
    ticker = Column(String(20), nullable=False)
    direction = Column(String(10), nullable=False)
    entry_price = Column(Float, nullable=False)
    stop_loss = Column(Float, nullable=False)
    target_price = Column(Float, nullable=False)
    strategy = Column(String(100))
    ai_score = Column(Float)

    # Outcome (filled on close)
    exit_price = Column(Float)
    pnl = Column(Float)
    pnl_pct = Column(Float)
    status = Column(String(20), default="open")   # open / closed / cancelled
    notes = Column(Text)

    # Scores snapshot for calibration
    macro_score_at_entry = Column(Float)
    theme_score_at_entry = Column(Float)
    pam_score_at_entry = Column(Float)

    opened_at = Column(DateTime, default=datetime.utcnow)
    closed_at = Column(DateTime)


# ═══════════════════════════════════════════════════════════
#  ANALYSIS JOBS (async tracking)
# ═══════════════════════════════════════════════════════════

class AnalysisJob(Base):
    __tablename__ = "analysis_jobs"

    job_id = Column(String(50), primary_key=True)
    tickers = Column(JSON, nullable=False)
    status = Column(String(20), default="pending")
    macro_context = Column(Text)
    error = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)

    ideas = relationship("TradeIdea", backref="job", lazy="selectin")
