"""Database engine, session, and initialization."""

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy import create_engine, text
from backend.config import settings
from backend.db.models import Base

# ── Async engine (FastAPI) ──
async_engine = create_async_engine(settings.DATABASE_URL, echo=False, pool_size=10)
AsyncSessionLocal = async_sessionmaker(async_engine, class_=AsyncSession, expire_on_commit=False)

# ── Sync engine (bootstrap, workers) ──
sync_engine = create_engine(settings.DATABASE_URL_SYNC, echo=False, pool_size=5)


async def get_db() -> AsyncSession:
    """Dependency for FastAPI routes."""
    async with AsyncSessionLocal() as session:
        yield session


async def init_db():
    """Create all tables + enable pgvector extension."""
    async with async_engine.begin() as conn:
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        await conn.run_sync(Base.metadata.create_all)


def init_db_sync():
    """Sync version for bootstrap scripts."""
    from sqlalchemy import text as sync_text
    with sync_engine.begin() as conn:
        conn.execute(sync_text("CREATE EXTENSION IF NOT EXISTS vector"))
    Base.metadata.create_all(sync_engine)
