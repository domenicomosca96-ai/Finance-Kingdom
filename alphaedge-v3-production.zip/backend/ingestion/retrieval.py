"""
RAG Retrieval — pgvector semantic search.

Replaces ChromaDB with native Postgres vector operations.
"""

from openai import OpenAI
from sqlalchemy import text
from sqlalchemy.orm import Session
from backend.config import settings
from backend.db.models import DocumentChunk

_openai = None

def get_openai() -> OpenAI:
    global _openai
    if _openai is None:
        _openai = OpenAI(api_key=settings.OPENAI_API_KEY)
    return _openai


def embed_text(content: str) -> list[float]:
    """Generate embedding vector for a text string."""
    client = get_openai()
    response = client.embeddings.create(
        model=settings.EMBEDDING_MODEL,
        input=content,
    )
    return response.data[0].embedding


def embed_batch(texts: list[str]) -> list[list[float]]:
    """Batch embedding."""
    client = get_openai()
    response = client.embeddings.create(
        model=settings.EMBEDDING_MODEL,
        input=texts,
    )
    return [d.embedding for d in response.data]


def retrieve(
    db: Session,
    query: str,
    collections: list[str] | None = None,
    k: int = 8,
) -> list[dict]:
    """
    Semantic search over document_chunks using pgvector cosine distance.

    Returns top-k chunks with content and metadata.
    """
    query_vec = embed_text(query)
    vec_str = "[" + ",".join(str(v) for v in query_vec) + "]"

    # Build SQL with optional collection filter
    where_clause = ""
    params = {"vec": vec_str, "k": k}
    if collections:
        placeholders = ",".join(f":c{i}" for i in range(len(collections)))
        where_clause = f"WHERE collection IN ({placeholders})"
        for i, c in enumerate(collections):
            params[f"c{i}"] = c

    sql = text(f"""
        SELECT id, collection, source, content, metadata,
               1 - (embedding <=> :vec::vector) AS similarity
        FROM document_chunks
        {where_clause}
        ORDER BY embedding <=> :vec::vector
        LIMIT :k
    """)

    result = db.execute(sql, params)
    rows = result.fetchall()

    return [
        {
            "id": r.id,
            "collection": r.collection,
            "source": r.source,
            "content": r.content,
            "metadata": r.metadata,
            "similarity": round(float(r.similarity), 4),
        }
        for r in rows
    ]


def multi_collection_retrieve(
    db: Session,
    query: str,
    collections: list[str],
    k_per_collection: int = 5,
) -> dict[str, list[dict]]:
    """Retrieve from each collection separately."""
    results = {}
    for coll in collections:
        results[coll] = retrieve(db, query, [coll], k_per_collection)
    return results


def format_retrieved_docs(docs_by_collection: dict) -> str:
    """Format for LLM context injection."""
    sections = []
    for coll, docs in docs_by_collection.items():
        if not docs:
            continue
        header = f"══ {coll.upper().replace('_', ' ')} ══"
        chunks = []
        for d in docs:
            chunks.append(f"[{d['source']}] (sim={d['similarity']})\n{d['content']}")
        sections.append(f"{header}\n\n" + "\n---\n".join(chunks))
    return "\n\n\n".join(sections)
