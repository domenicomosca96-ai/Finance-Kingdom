"""
AlphaEdge v3 — FastAPI with Postgres + pgvector + ARQ async jobs.

Key changes from v2:
- All data in Postgres (no ChromaDB)
- Analysis returns job_id (async via ARQ/Redis)
- Poll /api/jobs/{id} for results
- Deterministic PAM engine runs server-side
- 4-step chain prompting
"""

import os
import uuid
import json
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Depends, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text

from backend.config import settings
from backend.db.session import get_db, init_db, async_engine
from backend.db.models import (
    AnalysisJob, TradeIdea, PAMSignal, JournalEntry, DocumentChunk,
)
from backend.engine.market_data import run_full_pam, download_ohlcv
from backend.engine.scoring import compute_score, logistic_probability
from backend.ingestion.retrieval import embed_text, embed_batch


# ── Lifespan ─────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    print("✓ Database initialized (Postgres + pgvector)")
    yield
    await async_engine.dispose()


app = FastAPI(
    title="AlphaEdge AI v3",
    description="AI swing trading advisor — Postgres + deterministic PAM + chain prompting",
    version="3.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve frontend
FRONTEND = Path(__file__).parent.parent / "frontend"
if (FRONTEND / "dashboard.html").exists():
    @app.get("/")
    async def root():
        return FileResponse(FRONTEND / "dashboard.html")


# ═══════════════════════════════════════════════════════════
#  REQUEST / RESPONSE MODELS
# ═══════════════════════════════════════════════════════════

class AnalyzeRequest(BaseModel):
    tickers: list[str] = Field(..., min_length=1, max_length=20)
    context: str | None = None


class TickerQuickRequest(BaseModel):
    ticker: str


class UploadMeta(BaseModel):
    collection: str = "tech_reports"
    tags: str = ""


class JournalCreate(BaseModel):
    trade_idea_id: int | None = None
    ticker: str
    direction: str
    entry_price: float
    stop_loss: float
    target_price: float
    strategy: str = ""
    ai_score: float = 0


class JournalClose(BaseModel):
    id: int
    exit_price: float
    pnl: float
    notes: str = ""


# ═══════════════════════════════════════════════════════════
#  HEALTH
# ═══════════════════════════════════════════════════════════

@app.get("/api/health")
async def health(db: AsyncSession = Depends(get_db)):
    chunk_count = await db.scalar(text("SELECT count(*) FROM document_chunks"))
    return {
        "status": "ok",
        "version": "3.0.0",
        "database": "postgres+pgvector",
        "document_chunks": chunk_count or 0,
        "scoring": {
            "logistic_k": settings.LOGISTIC_K,
            "logistic_c": settings.LOGISTIC_C,
            "threshold": settings.SCORE_THRESHOLD,
        },
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# ═══════════════════════════════════════════════════════════
#  ANALYSIS (async job submission)
# ═══════════════════════════════════════════════════════════

@app.post("/api/analyze")
async def submit_analysis(req: AnalyzeRequest, db: AsyncSession = Depends(get_db)):
    """
    Submit a watchlist analysis job.
    Returns job_id immediately. Poll /api/jobs/{id} for results.

    If Redis/ARQ not available, falls back to synchronous execution.
    """
    job_id = f"job_{uuid.uuid4().hex[:12]}"
    tickers = [t.upper().strip() for t in req.tickers]

    job = AnalysisJob(job_id=job_id, tickers=tickers, status="pending")
    db.add(job)
    await db.commit()

    # Try ARQ async dispatch
    try:
        from arq import create_pool
        from arq.connections import RedisSettings

        redis = await create_pool(RedisSettings.from_dsn(settings.REDIS_URL))
        await redis.enqueue_job("process_analysis", job_id, tickers)
        return {"job_id": job_id, "status": "queued", "tickers": tickers}
    except Exception:
        # Fallback: run synchronously (slower but works without Redis)
        from backend.workers.analysis_worker import process_analysis
        try:
            await process_analysis({}, job_id, tickers)
        except Exception as e:
            job.status = "failed"
            job.error = str(e)
            await db.commit()
            raise HTTPException(500, str(e))

        return {"job_id": job_id, "status": "complete", "tickers": tickers}


@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str, db: AsyncSession = Depends(get_db)):
    """Poll job status and get results."""
    result = await db.execute(select(AnalysisJob).filter_by(job_id=job_id))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(404, "Job not found")

    response = {
        "job_id": job.job_id,
        "status": job.status,
        "tickers": job.tickers,
        "macro_context": job.macro_context,
        "created_at": job.created_at.isoformat() if job.created_at else None,
        "completed_at": job.completed_at.isoformat() if job.completed_at else None,
        "error": job.error,
    }

    if job.status == "complete":
        ideas_result = await db.execute(
            select(TradeIdea).filter_by(job_id=job_id).order_by(TradeIdea.probability_pct.desc())
        )
        ideas = ideas_result.scalars().all()
        response["analyses"] = [
            {
                "ticker": i.ticker,
                "raw_macro": i.raw_macro,
                "raw_theme": i.raw_theme,
                "raw_pam": i.raw_pam,
                "raw_composite": i.raw_composite,
                "probability_pct": i.probability_pct,
                "direction": i.direction,
                "actionable": i.actionable,
                "thesis": i.thesis,
                "swing_plan": i.swing_plan,
                "entry_price": i.entry_price,
                "stop_loss": i.stop_loss,
                "target_price": i.target_price,
                "option_strategy": i.option_strategy,
                "option_legs": i.option_legs,
                "option_rationale": i.option_rationale,
                "payoff_matrix": i.payoff_matrix,
                "kelly_fraction": i.kelly_fraction,
                "suggested_capital": i.suggested_capital,
                "suggested_contracts": i.suggested_contracts,
                "max_risk_dollars": i.max_risk_dollars,
                "invalidation": i.invalidation,
                "catalysts": i.catalysts,
            }
            for i in ideas
        ]

    return response


# ═══════════════════════════════════════════════════════════
#  PAM ENGINE (direct access)
# ═══════════════════════════════════════════════════════════

@app.get("/api/pam/{ticker}")
async def get_pam(ticker: str):
    """Run PAM engine for a single ticker and return pre-computed signals."""
    try:
        result = run_full_pam(ticker.upper())
        return {
            "ticker": result.ticker,
            "date": str(result.dt),
            "price": result.current_price,
            "sma_50": result.sma_50,
            "atr_14": result.atr_14,
            "rsi_14": result.rsi_14,
            "volume_ratio": result.volume_ratio,
            "flow": {
                "state": result.flow.state,
                "above_sma50": result.flow.above_sma50,
                "hh_hl_count": result.flow.hh_hl_count,
                "lh_ll_count": result.flow.lh_ll_count,
            },
            "momentum": {
                "is_flush": result.momentum.is_flush,
                "is_wave": result.momentum.is_wave,
                "angle_degrees": result.momentum.angle_degrees,
                "direction": result.momentum.direction,
                "flush_bar_count": result.momentum.flush_bar_count,
            },
            "pattern": {
                "name": result.pattern.pattern,
                "confirmed": result.pattern.confirmed,
                "confidence": result.pattern.confidence,
                "trigger": result.pattern.trigger_level,
                "stop": result.pattern.stop_level,
                "target": result.pattern.target_level,
                "rr_ratio": result.pattern.rr_ratio,
                "description": result.pattern.description,
            },
            "rotation_segment": result.rotation_segment,
            "micro_score": result.micro_score,
            "iv_rank": result.iv_rank,
            "days_to_earnings": result.days_to_earnings,
            "near_earnings": result.near_earnings,
            "context_string": result.to_context_string(),
        }
    except Exception as e:
        raise HTTPException(500, str(e))


# ═══════════════════════════════════════════════════════════
#  SCORING (direct test)
# ═══════════════════════════════════════════════════════════

@app.get("/api/score/test")
async def test_score(macro: float = 60, theme: float = 70, pam: float = 75):
    """Test the logistic scoring function with custom inputs."""
    result = compute_score(macro, theme, pam)
    return {
        "raw_macro": result.raw_macro,
        "raw_theme": result.raw_theme,
        "raw_pam": result.raw_pam,
        "raw_composite": result.raw_composite,
        "probability_pct": result.probability_pct,
        "confidence_tier": result.confidence_tier,
        "logistic_params": {"k": settings.LOGISTIC_K, "c": settings.LOGISTIC_C},
    }


# ═══════════════════════════════════════════════════════════
#  KNOWLEDGE BASE (PDF upload → pgvector)
# ═══════════════════════════════════════════════════════════

@app.post("/api/upload/pdf")
async def upload_pdf(
    file: UploadFile = File(...),
    collection: str = Form("tech_reports"),
    tags: str = Form(""),
    db: AsyncSession = Depends(get_db),
):
    """Upload PDF → extract → chunk → embed → store in pgvector."""
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(400, "PDF only")

    import fitz  # PyMuPDF
    from langchain.text_splitter import RecursiveCharacterTextSplitter

    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        content = await file.read()
        tmp.write(content)
        tmp_path = tmp.name

    try:
        doc = fitz.open(tmp_path)
        text_content = "\n\n".join(page.get_text("text") for page in doc if page.get_text("text").strip())
        doc.close()

        if not text_content.strip():
            return {"status": "error", "message": "No text extracted"}

        splitter = RecursiveCharacterTextSplitter(chunk_size=1200, chunk_overlap=200)
        chunks = splitter.split_text(text_content)
        embeddings = embed_batch(chunks)

        for i, (chunk, emb) in enumerate(zip(chunks, embeddings)):
            db.add(DocumentChunk(
                collection=collection,
                source=file.filename,
                chunk_index=i,
                content=chunk,
                embedding=emb,
                metadata_={"tags": tags, "total_chunks": len(chunks)},
            ))

        await db.commit()
        return {"status": "ok", "chunks": len(chunks), "collection": collection}
    finally:
        os.unlink(tmp_path)


@app.get("/api/collections")
async def collections(db: AsyncSession = Depends(get_db)):
    """List collections with chunk counts."""
    result = await db.execute(text(
        "SELECT collection, count(*) as cnt FROM document_chunks GROUP BY collection ORDER BY collection"
    ))
    return {"collections": [{"name": r.collection, "count": r.cnt} for r in result]}


# ═══════════════════════════════════════════════════════════
#  JOURNAL
# ═══════════════════════════════════════════════════════════

@app.post("/api/journal")
async def create_journal(req: JournalCreate, db: AsyncSession = Depends(get_db)):
    entry = JournalEntry(
        trade_idea_id=req.trade_idea_id,
        ticker=req.ticker.upper(),
        direction=req.direction,
        entry_price=req.entry_price,
        stop_loss=req.stop_loss,
        target_price=req.target_price,
        strategy=req.strategy,
        ai_score=req.ai_score,
    )
    db.add(entry)
    await db.commit()
    return {"id": entry.id, "status": "open"}


@app.put("/api/journal/close")
async def close_journal(req: JournalClose, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(JournalEntry).filter_by(id=req.id))
    entry = result.scalar_one_or_none()
    if not entry:
        raise HTTPException(404, "Not found")

    entry.exit_price = req.exit_price
    entry.pnl = req.pnl
    entry.pnl_pct = (req.pnl / (entry.entry_price * 100)) * 100 if entry.entry_price else 0
    entry.status = "closed"
    entry.notes = req.notes
    entry.closed_at = datetime.now(timezone.utc)
    await db.commit()
    return {"id": entry.id, "status": "closed", "pnl": req.pnl}


@app.get("/api/journal")
async def list_journal(status: str = "all", db: AsyncSession = Depends(get_db)):
    query = select(JournalEntry).order_by(JournalEntry.opened_at.desc())
    if status != "all":
        query = query.filter_by(status=status)
    result = await db.execute(query)
    entries = result.scalars().all()
    return {"entries": [
        {
            "id": e.id, "ticker": e.ticker, "direction": e.direction,
            "entry_price": e.entry_price, "stop_loss": e.stop_loss,
            "target_price": e.target_price, "exit_price": e.exit_price,
            "pnl": e.pnl, "status": e.status, "strategy": e.strategy,
            "ai_score": e.ai_score,
            "opened_at": e.opened_at.isoformat() if e.opened_at else None,
            "closed_at": e.closed_at.isoformat() if e.closed_at else None,
        }
        for e in entries
    ]}


# ═══════════════════════════════════════════════════════════

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
