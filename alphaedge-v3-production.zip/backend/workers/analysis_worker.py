"""
ARQ Worker — Async analysis pipeline.

The FastAPI endpoint enqueues a job and returns job_id immediately.
This worker processes the full chain asynchronously.
"""

import json
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from backend.config import settings
from backend.db.session import sync_engine
from backend.db.models import AnalysisJob, TradeIdea, PAMSignal
from backend.engine.market_data import run_full_pam
from backend.engine.scoring import compute_score, compute_sizing
from backend.engine.options_mapper import select_strategy
from backend.engine.chain import run_chain
from backend.ingestion.retrieval import (
    multi_collection_retrieve, format_retrieved_docs,
)
from sqlalchemy.orm import Session as SyncSession


ALL_COLLECTIONS = [
    "macro_liquidity", "trading_methods", "pam_structures",
    "tech_reports", "watchlist_setups",
]


async def process_analysis(ctx: dict, job_id: str, tickers: list[str]):
    """
    Full analysis pipeline (runs in ARQ worker):
    1. Run deterministic PAM engine for each ticker
    2. Retrieve relevant docs from pgvector
    3. Run 4-step chain prompting
    4. Apply logistic scoring + position sizing + options mapping
    5. Store results in Postgres
    """
    with SyncSession(sync_engine) as db:
        job = db.query(AnalysisJob).filter_by(job_id=job_id).first()
        if not job:
            return
        job.status = "running"
        db.commit()

        try:
            # ── Step 1: PAM Engine (deterministic) ──
            pam_results = {}
            pam_context_parts = []
            for ticker in tickers:
                try:
                    pam = run_full_pam(ticker)
                    pam_results[ticker] = pam
                    pam_context_parts.append(pam.to_context_string())

                    # Store PAM signal
                    signal = PAMSignal(
                        ticker=ticker,
                        dt=pam.dt,
                        flow_state=pam.flow.state,
                        above_sma50=pam.flow.above_sma50,
                        hh_hl_count=pam.flow.hh_hl_count,
                        lh_ll_count=pam.flow.lh_ll_count,
                        pattern=pam.pattern.pattern,
                        pattern_confidence=pam.pattern.confidence,
                        trigger_level=pam.pattern.trigger_level,
                        stop_level=pam.pattern.stop_level,
                        target_level=pam.pattern.target_level,
                        flush_detected=pam.momentum.is_flush,
                        flush_direction=pam.momentum.direction,
                        momentum_angle_deg=pam.momentum.angle_degrees,
                        is_wave=pam.momentum.is_wave,
                        is_flush=pam.momentum.is_flush,
                        rotation_segment=pam.rotation_segment,
                        micro_score=pam.micro_score,
                    )
                    db.merge(signal)
                except Exception as e:
                    pam_context_parts.append(f"── {ticker}: PAM ERROR: {e} ──")

            db.commit()
            pam_context = "\n\n".join(pam_context_parts)

            # ── Step 2: RAG Retrieval ──
            query = f"Swing trading analysis {' '.join(tickers)} liquidity PAM setup catalysts"
            docs = multi_collection_retrieve(db, query, ALL_COLLECTIONS, k_per_collection=4)
            retrieved_str = format_retrieved_docs(docs)

            # ── Step 3: Live data context ──
            live_parts = []
            for ticker, pam in pam_results.items():
                live_parts.append(
                    f"{ticker}: ${pam.current_price} | RSI: {pam.rsi_14} | "
                    f"ATR: {pam.atr_14} | Vol ratio: {pam.volume_ratio}x"
                )
            live_str = "\n".join(live_parts)

            # ── Step 4: Chain prompting (4 LLM calls) ──
            chain_result = await run_chain(retrieved_str, pam_context, live_str, tickers)

            macro_context = chain_result.get("macro_context", "")
            analyses = chain_result.get("analyses", [])

            job.macro_context = macro_context

            # ── Step 5: Score + Size + Options for each ticker ──
            for analysis in analyses:
                ticker = analysis.get("ticker", "")
                pam = pam_results.get(ticker)
                if not pam:
                    continue

                # Logistic scoring
                score_result = compute_score(
                    raw_macro=analysis.get("raw_macro", 50),
                    raw_theme=analysis.get("raw_theme", 50),
                    raw_pam=pam.micro_score,
                )

                entry = analysis.get("entry_price") or pam.pattern.trigger_level or pam.current_price
                stop = analysis.get("stop_loss") or pam.pattern.stop_level
                target = analysis.get("target_price") or pam.pattern.target_level

                # Position sizing
                sizing = None
                if entry and stop and target:
                    sizing = compute_sizing(
                        probability=score_result.probability_pct,
                        entry_price=entry,
                        stop_price=stop,
                        target_price=target,
                    )

                # Options strategy — now with real IV rank and earnings data
                options = None
                if score_result.probability_pct >= settings.SCORE_THRESHOLD:
                    options = select_strategy(
                        pattern=pam.pattern,
                        flow=pam.flow,
                        momentum=pam.momentum,
                        current_price=pam.current_price,
                        rsi=pam.rsi_14,
                        iv_rank=pam.iv_rank,
                        near_earnings=pam.near_earnings,
                        days_to_earnings=pam.days_to_earnings,
                    )

                # Store trade idea
                idea = TradeIdea(
                    job_id=job_id,
                    ticker=ticker,
                    dt=pam.dt,
                    raw_macro=score_result.raw_macro,
                    raw_theme=score_result.raw_theme,
                    raw_pam=score_result.raw_pam,
                    raw_composite=score_result.raw_composite,
                    probability_pct=score_result.probability_pct,
                    direction=analysis.get("direction", "neutral"),
                    actionable=score_result.probability_pct >= settings.SCORE_THRESHOLD,
                    thesis=analysis.get("thesis"),
                    swing_plan=analysis.get("swing_plan"),
                    entry_price=entry,
                    stop_loss=stop,
                    target_price=target,
                    option_strategy=options.strategy_name if options else None,
                    option_legs=[{"side": l.side, "type": l.type, "strike": l.strike, "expiry": l.expiry, "qty": l.quantity} for l in options.legs] if options else None,
                    option_rationale=options.rationale if options else None,
                    payoff_matrix=[{"price": p.price, "pnl": p.pnl, "pnl_pct": p.pnl_pct, "label": p.label} for p in options.payoff_matrix] if options and options.payoff_matrix else None,
                    kelly_fraction=sizing.kelly_adjusted if sizing else None,
                    suggested_capital=sizing.capital_allocated if sizing else None,
                    suggested_contracts=sizing.contracts if sizing else None,
                    max_risk_dollars=sizing.dollar_risk if sizing else None,
                    invalidation=analysis.get("invalidation"),
                    catalysts=analysis.get("catalysts", []),
                    llm_raw_output=json.dumps(analysis),
                )
                db.add(idea)

            job.status = "complete"
            job.completed_at = datetime.now(timezone.utc)
            db.commit()

        except Exception as e:
            job.status = "failed"
            job.error = str(e)
            db.commit()
            raise
