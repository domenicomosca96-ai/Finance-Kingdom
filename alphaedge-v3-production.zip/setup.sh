#!/bin/bash
# AlphaEdge v3 — Setup Script
# Requires: Python 3.11+, Postgres with pgvector, Redis (optional)

set -e
GREEN='\033[0;32m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'; BOLD='\033[1m'

echo ""
echo -e "${CYAN}══ AlphaEdge v3 Setup ══${NC}"
echo ""

# 1. Python check
PYTHON=$(command -v python3.11 || command -v python3 || echo "")
if [ -z "$PYTHON" ]; then echo -e "${RED}Python 3 not found${NC}"; exit 1; fi
echo -e "  ${GREEN}✓${NC} $($PYTHON --version)"

# 2. Virtual env
if [ ! -d ".venv" ]; then $PYTHON -m venv .venv; fi
source .venv/bin/activate
echo -e "  ${GREEN}✓${NC} Virtual environment"

# 3. Install deps
pip install --upgrade pip -q
pip install -r requirements.txt -q
echo -e "  ${GREEN}✓${NC} Dependencies installed"

# 4. Env file
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo ""
    echo -e "  ${BOLD}Configure API keys in .env:${NC}"
    echo -e "    ANTHROPIC_API_KEY (required)"
    echo -e "    OPENAI_API_KEY (required for embeddings)"
    echo -e "    DATABASE_URL (defaults to localhost:5432/alphaedge)"
    echo ""
fi
echo -e "  ${GREEN}✓${NC} .env ready"

# 5. Directories
mkdir -p data/knowledge data/pdfs frontend
echo -e "  ${GREEN}✓${NC} Directories"

# 6. Database + Knowledge bootstrap
echo ""
echo -e "  ${BOLD}Bootstrapping knowledge base...${NC}"
echo -e "  (Requires Postgres running with pgvector extension)"
echo ""
$PYTHON -m backend.bootstrap || echo -e "  ${RED}Bootstrap failed — check DB connection${NC}"

echo ""
echo -e "${GREEN}══ Setup Complete ══${NC}"
echo ""
echo -e "  Start: ${CYAN}source .venv/bin/activate && python -m backend.main${NC}"
echo -e "  Open:  ${CYAN}http://localhost:8000${NC}"
echo -e "  Docs:  ${CYAN}http://localhost:8000/docs${NC}"
echo ""
echo -e "  Or with Docker: ${CYAN}docker-compose up -d${NC}"
echo ""
